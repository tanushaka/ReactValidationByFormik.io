import React from "react";
// import Cart from "./component/Cart";
import Cart from "./components/Cart";

const App = () => {
  return (
    <>
      <Cart />
    </>
  );
};

export default App;
